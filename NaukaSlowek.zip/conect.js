import mongodb from "mongodb";
const MongoClient = mongodb.MongoClient
// Replace the following with your Atlas connection string                                                                                                                                        
const url = "mongodb+srv://hawuka:haseloHaselo@slowka.qprfm5a.mongodb.net/test?retryWrites=true&w=majority&useNewUrlParser=true&useUnifiedTopology=true";
const client = new MongoClient(url);
async function run() {
  try {
    await client.connect();
    console.log("Connected correctly to server");
  } catch (err) {
    console.log(err);
  }
  finally {
    await client.close();
  }
}
run().catch(console.dir);